def inicio(db_usuarios): #FUNCION PARA INICIAR SECION Y ACCEDER A LAS FUNCIONES DEL MAIN
    while True:
        iniciosesion=input("Ingresa tu usuario ")
        x = True        
        for user in db_usuarios:
            if user.name == iniciosesion:
                db_usuarios.remove(user)
                db_usuarios.append(user)
                x = False
                break
        if x:
            print("El usuario que intenta registrar no esta registrado ❌. Intente con otro usuario ")
        else:
            break
