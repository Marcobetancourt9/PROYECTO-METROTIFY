import requests
from Objetos.usuario import Usuario
from Objetos.usuario import Escucha
from Objetos.usuario import Musico
from Objetos.cancion import Cancion
from Objetos.album import Album
from Objetos.playlist import Playlist

# MODULO MANEJO DE INFORMACION

def download_api(): #EXTRAE TODA LA INFORMACION DE LA API
        """ Extrae informacion de la API y escribe .TXT 
        """
        
        print('\nIniciando descarga... ⬇️')

        r_albums = requests.request("GET", 'https://raw.githubusercontent.com/Algoritmos-y-Programacion/api-proyecto/main/albums.json')
        r_playlist = requests.request("GET", 'https://raw.githubusercontent.com/Algoritmos-y-Programacion/api-proyecto/main/playlists.json')
        r_usuarios = requests.request("GET", 'https://raw.githubusercontent.com/Algoritmos-y-Programacion/api-proyecto/main/users.json')

        directory = './Basededatos/'#DIRECTORIO AL QUE VA DIRIGIDO
        
        file_name = 'db_albums.txt'#LLENA EL TXT CON LOS DATOS DE LA API
        with open(directory + file_name, 'w') as file:
            for album in r_albums.json():
                a_description = album["description"].split("\n")[0] + album["description"].split("\n")[1]
                file.write(f'{album["id"]},{album["name"]},{album["genre"]},{album["artist"]},{album["cover"]},{album["published"]},{a_description},{0}\n')

        file_name = 'db_usuarios.txt'#LLENA EL TXT CON LOS DATOS DE LA API
        with open(directory + file_name, 'w') as file:
            for usuario in r_usuarios.json():
                file.write(f'{usuario["id"]},{usuario["name"]},{usuario["email"]},{usuario["type"]},{usuario["username"]},{0}*\n')

        file_name = 'db_playlist.txt'#LLENA EL TXT CON LOS DATOS DE LA API
        with open(directory + file_name, 'w') as file:
            for play in r_playlist.json():
                p_description = play["description"].split("\n")[0] + play["description"].split("\n")[1]
                file.write(f'{play["id"]},{play["name"]},{p_description},{play["creator"]},{play["tracks"]},{0}\n')

        file_name = 'db_likes.txt'#NO ES NECESARIO LLENARLOS POR EL MOMENTO
        with open(directory + file_name, 'w') as file:
            file.write('')

        file_name = 'db_canciones.txt'#LLENA EL TXT CON LOS DATOS DE LA API EN EL ALBUM
        with open(directory + file_name, 'w') as file:    
            for album in r_albums.json():
                for cancion in album["tracklist"]:
                    file.write(f'{album["id"]}, {cancion["id"]}, {cancion["name"]},{cancion["duration"]},{cancion["link"]},{0}*\n')

        file_name = 'db_musicos.txt'#NO ES NECESARIO LLENARLOS POR EL MOMENTO
        with open(directory + file_name, 'w') as file:
            file.write('')

        file_name = 'db_oyentes.txt'#NO ES NECESARIO LLENARLOS POR EL MOMENTO
        with open(directory + file_name, 'w') as file:
            file.write('')

        print('Informacion actualizada exitosamente! ✅')

def read_files(): #LLENA LAS LISTAS Y LAS SEPARA COMO DEBERIAN ESTAR
        directory = './Basededatos/'
        
        try:
            db_usuarios = []
            file_name = 'db_usuarios.txt'#LLENA LA LISTA
            with open(directory + file_name) as file:
                for usuario in file:
                    new_usuario = Usuario(usuario.split(',')[0],usuario.split(',')[1], usuario.split(',')[2], usuario.split(',')[3], usuario.split(',')[4])
                    db_usuarios.append(new_usuario)
        except FileNotFoundError:
            print("Todavía no existe el archivo de usuarios, se leerá de la API")
            print("Corra el programa nuevamente para acceder a todas las funciones")
            db_usuarios  = download_api() #SI NO EXISTEN LOS TXT LOS CREA

        try:
            db_musicos = []
            file_name = 'db_musicos.txt'#NO LLENA LA LISTA, POR EL MOMENTO
            with open(directory + file_name) as file:
                for musico in file:
                    new_musico = Musico(musico.split(',')[0],musico.split(',')[1], musico.split(',')[2], musico.split(',')[3], musico.split(',')[4], musico.split(',')[5], int(musico.split(',')[6]))
                    db_musicos.append(new_musico)
        except FileNotFoundError:
            print("Todavía no existe el archivo de usuarios, se leerá de la API")
            print("Corra el programa nuevamente para acceder a todas las funciones")
            db_musicos  = download_api() #SI NO EXISTEN LOS TXT LOS CREA

        try:    
            db_oyentes = []
            file_name = 'db_oyentes.txt'#NO LLENA LA LISTA, POR EL MOMENTO
            with open(directory + file_name) as file:
                for escucha in file:
                    new_escucha = Escucha(escucha.split(',')[0],escucha.split(',')[1], escucha.split(',')[2], escucha.split(',')[3], escucha.split(',')[4], escucha.split(',')[5], int(escucha.split(',')[6]))
                    db_oyentes.append(new_escucha)
        except FileNotFoundError:
            print("Todavía no existe el archivo de usuarios, se leerá de la API")
            print("Corra el programa nuevamente para acceder a todas las funciones")
            db_oyentes  = download_api()  #SI NO EXISTEN LOS TXT LOS CREA


        try:
            db_canciones = []
            file_name = 'db_canciones.txt'#LLENA LA LISTA
            with open(directory + file_name) as file:
                for cancion in file:
                    new_cancion = Cancion(cancion.split(',')[0],cancion.split(',')[1], cancion.split(',')[2], cancion.split(',')[3], cancion.split(',')[4])
                    db_canciones.append(new_cancion)
        except FileNotFoundError:
            print("Todavía no existe el archivo de usuarios, se leerá de la API")
            print("Corra el programa nuevamente para acceder a todas las funciones")
            db_canciones  = download_api()  #SI NO EXISTEN LOS TXT LOS CREA

        try:
            db_playlist = []
            file_name = 'db_playlist.txt'#LLENA LA LISTA
            with open(directory + file_name) as file:
                for list in file:
                    new_playlist = Playlist(list.split(',')[0],list.split(',')[1], list.split(',')[2], list.split(',')[3], list.split(',')[4])
                    db_playlist.append(new_playlist)
        except FileNotFoundError:
            print("Todavía no existe el archivo de usuarios, se leerá de la API")
            print("Corra el programa nuevamente para acceder a todas las funciones")
            db_playlist  = download_api() #SI NO EXISTEN LOS TXT LOS CREA

        try:
            db_albums = []
            file_name = 'db_albums.txt'#LLENA LA LISTA
            with open(directory + file_name) as file:
                for album in file:
                    new_album = Album(album.split(',')[0],album.split(',')[1], album.split(',')[2], album.split(',')[3], album.split(',')[4], album.split(',')[5], album.split(',')[6], int(album.split(',')[7]))
                    db_albums.append(new_album)
        except FileNotFoundError:
            print("Todavía no existe el archivo de usuarios, se leerá de la API")
            print("Corra el programa nuevamente para acceder a todas las funciones")
            db_albums  = download_api()  #SI NO EXISTEN LOS TXT LOS CREA

        return db_usuarios, db_musicos, db_oyentes, db_albums, db_canciones, db_playlist

def actualizacion():#ACTUALIZA DATOS CUANDO SE CIERRA EL PROGRAMA
    directory = './Basededatos/'
    
    db_usuarios = []
    file_name = 'db_usuarios.txt'#ACTUALIZA LOS DATOS CON LA LISTA
    with open(directory + file_name, 'a') as file:
        for usuario in db_usuarios:
            file.write(f'{usuario.id},{usuario.name},{usuario.correo},{usuario.tipo},{usuario.username},{usuario.streams}*\n')

    db_albums = []
    file_name = 'db_albums.txt'#ACTUALIZA LOS DATOS CON LA LISTA
    with open(directory + file_name, 'a') as file:
        for album in db_albums:
            file.write(f'{album.id},{album.name},{album.genero},{album.artista},{album.cover},{usuario.published},{usuario.descripcion},{usuario.streams}*\n')
    
    db_playlist = []
    file_name = 'db_playlist.txt'#ACTUALIZA LOS DATOS CON LA LISTA
    with open(directory + file_name, 'a') as file:
        for play in db_playlist:
            file.write(f'{play.id},{play.name},{play.descripcion},{play.creador},{play.streams}*\n')

    db_canciones = []
    file_name = 'db_canciones.txt'#ACTUALIZA LOS DATOS CON LA LISTA
    with open(directory + file_name, 'a') as file:
        for cancion in db_canciones:
            file.write(f'{cancion.id},{cancion.name},{cancion.duracion},{cancion.link},{cancion.streams}*\n')

    db_likes=[]#ACTUALIZA LOS DATOS CON LA LISTA
    file_name = 'db_likes.txt'
    with open(directory + file_name, 'a') as file:
        for like in db_likes:
            file.write(f'{like.id},{like.item},{like.id_item}')