import matplotlib.pyplot as plt

def plot_top5(musicos, item): #GRAFICO PARA CADA FUNCIÓN
    nombres_musicos = [musico.name for musico in musicos]
    streams_musico = [musico.streams for musico in musicos]

    plt.barh(nombres_musicos, streams_musico)
    plt.xlabel('Streams')
    plt.ylabel('Musico')
    plt.title(f'Los 5 {item} con más reproducciones en streaming')
    plt.gca().invert_yaxis()
    plt.show()

def top5musicos(musician_list):
    sorted_musicos = sorted(musician_list, key=lambda x: x.streams, reverse=True)
    
    # Devolver los primeros 5 músicos con la mayor cantidad de streams
    return sorted_musicos[:5]

def top_artistas(db_usuarios, usuario): #GRAFICO DE LOS USUARIOS MUSICO
    musicos=[]
    for user in db_usuarios:
                if user.tipo == "musician":
                    musicos.append(user)
    top_5_musicos = top5musicos(musicos)
    for i, musico in enumerate(top_5_musicos, 1):
        print(f'\n#{i}:')
        print(musico)
    plot_top5(top_5_musicos,usuario)

def top5escuchas(escucha_list):
    sorted_escuchas = sorted(escucha_list, key=lambda x: x.streams, reverse=True)
    
    # Devolver los primeros 5 escuchas con la mayor cantidad de streams
    return sorted_escuchas[:5]

def top_escuchas(db_usuarios, escucha): #GRAFICO DE LOS USUARIOS ESCUCHA
    escucha="escucha"
    escuchas=[]
    for user in db_usuarios:
                if user.tipo == "listener":
                    escuchas.append(user)
    top_5_escuchas = top5escuchas(escuchas)
    for i, musico in enumerate(top_5_escuchas, 1):
        print(f'\n#{i}:')
        print(musico)
    plot_top5(top_5_escuchas, escucha)

def top5albums(album_list):
    sorted_albums = sorted(album_list, key=lambda x: x.streams, reverse=True)
    
    # Devolver los primeros 5 albumes con la mayor cantidad de streams
    return sorted_albums[:5]

def top_albums(db_albums, albumes): #GRAFICO DE LOS ALBUMES
    albumes="albumes"
    albums=[]
    for album in db_albums:
        albums.append(album)
    top_5_albums = top5albums(albums)
    for i, album in enumerate(top_5_albums, 1):
        print(f'\n#{i}:')
        print(album)
    plot_top5(top_5_albums, albumes)

def top5canciones(cancion_list):
    sorted_canciones = sorted(cancion_list, key=lambda x: x.streams, reverse=True)
    
    # Devolver las primeros 5 canciones con la mayor cantidad de streams
    return sorted_canciones[:5]

def top_canciones(db_canciones, canción): #GRAFICO DE LAS CANCIONES
    canción="canción"
    canciones=[]
    for cancion in db_canciones:
        canciones.append(cancion)
    top_5_canciones = top5canciones(canciones)
    for i, cancion in enumerate(top_5_canciones, 1):
        print(f'\n#{i}:')
        print(cancion)
    plot_top5(top_5_canciones, canción)