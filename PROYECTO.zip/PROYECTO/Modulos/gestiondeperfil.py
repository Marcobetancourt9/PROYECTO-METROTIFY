from Objetos.usuario import Usuario
import uuid

def generar_id():
    return str(uuid.uuid4())

def crearperfil(db_usuarios): #CREAR NUEVO PERFIL   
        id_generado = generar_id()    
        streams=0       
        while True:    
            nombre=input("Ingresa tu nombre o nombre artisitico >>> ")
            username=nombre+"_"
            correo_electronico= input("Ingresa tu correo_electronico sin @ ni caracteres luego de de esto >>> ")
            caracter=input("""Ingresa el numero de tu tipo de correo_electronico:
                                1.gmail.com
                                2.hotmail.com
                                3.unimet.edu.ve
                                >>> """)
            if caracter=="1":
                correo_electronico+="@gmail.com"
            elif caracter=="2":
                correo_electronico+="@hotmail.com"
            elif caracter=="3":
                correo_electronico+="@unimet.edu.ve "
            else:
                print("Tu correo no es valido ingresa una opción valida")
                break

            tipo_de_usuario=input("""Ingresa el numero de la opcion de tu tipo de usuario
                                    1. Músico
                                    2. Escucha
                                    >>>""")
            if tipo_de_usuario=="1":
                tipo_de_usuario = "musician"
                datosnew=Usuario({id_generado}, {nombre}, {correo_electronico}, {tipo_de_usuario}, {username}, {streams})
                db_usuarios.append(datosnew)            
                print("Tu usuario fue creado exitosamente✅")
                break
            elif tipo_de_usuario=="2":
                tipo_de_usuario = "listener"
                datosnew=Usuario( {id_generado}, {nombre}, {correo_electronico}, {tipo_de_usuario}, {username})
                db_usuarios.append(datosnew)
                print("Tu usuario fue creado exitosamente✅")
                break
            else:
                print("La opcion no es valida escoge un valor valido❌")
                break

def buscarusuarios(db_usuarios):#BUSCAR PERFILES POR EL NOMBRE
        """            
        2. Buscar perfiles en función de los siguientes filtros:
        a. Nombre"""
        busqueda=input("Ingresa el nombre del usuario ")
        for user in db_usuarios:
            if user.name == busqueda:
                user.play()
                return user
       
def cambiarinfo(db_usuarios):#CAMBIAR INFORMACION DE UN PERFIL
        user = buscarusuarios(db_usuarios)
        if user == None:
            print("El usuario que intenta buscar no esta registrado ❌. Intente con otro usuario ")
            return
        
        """3. Cambiar la información personal de la cuenta."""
        while True:
            # SOLICITA AL USUARIO LA INFORMACION QUE DESEA CAMBIAR
            opcion_cambio = input("""¿Qué información deseas cambiar?
                                1. Nombre
                                2. Correo electrónico
                                3. Tipo de usuario
                                4. Username
                                >>> """)
            # REALIZAR LOS CAMBIOS QUE PIDA EL USUARIO
            if opcion_cambio == "1":
                nuevo_nombre = input("Ingresa el nuevo nombre: ")
                user.name = nuevo_nombre
                break
            elif opcion_cambio == "2":
                nuevo_correo = input("Ingresa el nuevo correo electrónico: ")
                user.email = nuevo_correo
                break
            elif opcion_cambio == "3":
                nuevo_tipo_usuario = input("""Ingresa el número del tipo de usuario:
                                            1. Músico
                                            2. Escucha
                                            >>> """)
                if nuevo_tipo_usuario=="1":
                    nuevo_tipo_usuario = "musician"  
                    user.user_type = nuevo_tipo_usuario
                    print("Tu tipo usuario fue cambiado exitosamente✅")                        
                    break
                elif nuevo_tipo_usuario=="2":
                    nuevo_tipo_usuario = "listener"
                    user.user_type = nuevo_tipo_usuario
                    print("Tu tipo usuario fue cambiado exitosamente✅")
                    break
                else:
                    print("La opcion no es valida escoge un valor valido❌")
                    break
            elif opcion_cambio == "4":
                nuevo_username = input("Ingresa el nuevo username: ")
                user.username = nuevo_username
                break
            else:
                print("Opción no válida.")
                break
                
        print("La información del usuario ha sido actualizada exitosamente. ✅")
        print("Información actualizada del usuario:")
        print(user)
                 
def borrar(db_usuarios):#BORRAR USUARIOS 
        borrar=("Escribe el nombre de la cuenta que deseas borrar 🗒️")        
        """4. Borrar los datos de la cuenta."""
        borrar=input("Ingresa el nombre de lo que deseas borrar ")
        for user in db_usuarios:
            if user.name == borrar:
                 db_usuarios.remove(user)