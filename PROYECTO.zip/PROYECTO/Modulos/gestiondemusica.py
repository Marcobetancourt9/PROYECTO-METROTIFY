from Objetos.album import Album
from Objetos.playlist import Playlist
from Objetos.cancion import Cancion
import uuid
from datetime import datetime

def generar_id():
    return str(uuid.uuid4())

def crearalbum(db_albums, db_usuarios): #CREAR NUEVO ALBÚM
    """Este módulo permitirá a los usuarios de tipo músico, subir sus álbumes con
    canciones; y le permitirá a los usuarios escuchas crear playlist y darle like a estos.
    Para ello, se deberá desarrollar lo siguiente:
    1. Crear un álbum musical:
        a. Deberá darle un nombre y descripción
        b. Portada del album [link]
        c. Fecha de publicación
        d. Género predominante
        e. Tracklist
            i. Cada canción tendrá un nombre
            ii. Una duración en minutos
            iii. Deberá permitir ser likeada por otros usuarios"""
    while True:
        if db_usuarios[-1].tipo == "musician":
            id_generado = generar_id() #CREA UN ID DIFERENTE PARA CADA PERSONA
            nombre_album=input("Ingresa el nombre del album musical >>> ") #TIENES QUE INGRESAR LOS DATOS
            artista= db_usuarios[-1].name #TU NOMBRE ES EL QUE APARECE COMO EL CREADOR
            descripcion= input("Ingresa la descripción >>> ") #TIENES QUE INGRESAR LOS DATOS
            link=input("""Ingresa la portada del album "link" >>> """) #TIENES QUE INGRESAR LOS DATOS
            fecha_hora_actual = datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%S.%fZ') #AGREGA LA FECHA ACTUAL
            genero= input("Ingresa el género predominante >>> ") #TIENES QUE INGRESAR LOS DATOS
            tracklist= int(input("Cuantas canciones deseas: ")) #TIENES QUE INGRESAR LOS DATOS SOLO NUMEROS
            lista_canciones=[]
            while tracklist > 0: #GENERA CANCIONES Y LLENA LA LISTA DE ARRIBA
                streams=0
                id_cancion = generar_id() 
                nombretrak= input("Ingrese Nombre: ") #TIENES QUE INGRESAR LOS DATOS
                duraciontrak= input("Ingrese Duracion: ")#TIENES QUE INGRESAR LOS DATOS
                linktrak= input("Ingrese Link: ") #TIENES QUE INGRESAR LOS DATOS
                cancion=Cancion({id_generado},{id_cancion}, {nombretrak}, {duraciontrak}, {linktrak}, {streams})
                lista_canciones.append(cancion)
                tracklist -=1
            datosnew=Album({id_generado}, {nombre_album}, {genero}, {artista}, lista_canciones, {link}, {fecha_hora_actual}, {descripcion})
            db_albums.append(datosnew)    #TERMINA DE CREAR EL ALBUM        
            print("Tu album fue creado exitosamente✅")
        else: #VALIDACION ERES MUSICO
            print("El usuario no es de tipo músico no puedes crear un albúm. Ingresa otro usuario o crea uno.")
            break
        break

def escuchar(db_albums, db_canciones, db_usuarios, db_playlist): #ESCUCHAR MUSICA 
    """Un usuario Escucha (A) puede escuchar la música de un músico (B) de las
    siguientes formas:
    a. Podrá buscar el álbum o las canciones por su nombre en un buscador.
    b. Podrá acceder a las canciones entrando al perfil del músico
    c. Podrá escuchar la canción a través de una playlist."""
    
    opcion= input("""Ingrese la opción a la que desea acceder:
                     1. Buscar el álbum o las canciones por su nombre en un buscador.
                     2. Acceder a las canciones entrando al perfil del músico
                     3. Escuchar la canción a través de una playlist.
                     >>>>> """)
    while True:
        if opcion == "1": #BUSCA ALBUMES Y CANCIONES
            print("Ingresa si quieres buscar por album o por canción")
            eleccion=input("""
                              1.Album
                              2.Canción
                              3.Salir
                              >>>>> """)
            if eleccion == "1": #BUSCA UN ALBUM Y SIMULA QUE ESTA REPRODUCIENDOSE
                nombre = input("Ingrese el nombre del álbum ")
                album = buscaralbums(db_albums, nombre) #BUSCA UN ALBUM
                album.play() #SIMULA QUE ESTA REPRODUCIENDOSE
                
                if album == None:
                    print("El álbum que intenta buscar no esta registrado ❌. Intente con otro álbum ")   
                    break
            if eleccion == "2": #BUSCA UNA CANCION Y SIMULA QUE LA ESTA REPRODUCIENDO
                nombre = input("Ingrese el nombre de la canción ")
                cancion = buscarcancion(db_canciones, nombre) #BUSCA LA CANCION
                cancion.play()#LA REPRODUCE

                if cancion == None:
                    print("La canción que intenta buscar no esta registrado ❌. Intente con otra canción ")   
                    break
            
            elif eleccion == "3": #SALIR
                print("Ha logrado salir con exito. Hasta luego 👋")      
                break

        elif opcion == "2": #ACCEDE A LA CUENTA DE UN MUSICO Y GENERA UNA VISTA 
            nombre = input("Ingrese el nombre de la canción ")
            musico = buscarmusico(db_usuarios)
            musico.play()

            if musico == None:
                print("El músico que intentas buscar no esta registrado ❌. Intente con otro musico ")   
                break

        elif opcion == "3": #ACCEDE A LA PLAYLIST PARA BUSCAR LAS CANCIONES
            nombre = input("Ingrese el nombre de la playlist ")
            play = buscarplaylist(db_playlist)
            play.play()
            
            if play == None:
                print("El playlist que intentas buscar no esta registrado ❌. Intente con otro playlist ")   
                break

def crearplaylist(db_playlist,db_usuarios): #CREAR PLAYLIST; SIMILAR AL CREAR ALBUM, PERO AQUI SOLO PUEDEN CREAR USUARIOS ESCUCHA
    """ 3. Un usuario podrá crear un playlist, para ello deberá:
            a. Darle un título
            b. Una descripción
            c. Agregar un conjunto de canciones [deberá buscarlas por nombre o por
            artista]
            d. Se deberá asociar al creador de este playlist"""  
    while True:
        if db_usuarios[-1].tipo == "listener": 
            titulo_playlist=input("Ingresa el nombre de la playlist musical >>> ") #TIENES QUE INGRESAR LOS DATOS
            conjuntodecanciones= int(input("Cuantas canciones deseas: "))#TIENES QUE INGRESAR LOS DATOS SOLO NUMEROS
            lista_canciones=[]
            while conjuntodecanciones > 0:
                id_cancion = generar_id() #CREA UN ID DIFERENTE PARA CADA PERSONA
                creador= db_usuarios[-1].name #TU NOMBRE ES EL QUE APARECE COMO EL CREADOR
                nombrecancion= input("Ingrese Nombre: ") #TIENES QUE INGRESAR LOS DATOS
                duracioncancion= input("Ingrese Duracion: ")#TIENES QUE INGRESAR LOS DATOS
                linkcancion= input("Ingrese Link: ")#TIENES QUE INGRESAR LOS DATOS
                cancion=Cancion({id_cancion}, {creador}, {nombrecancion}, {duracioncancion}, {linkcancion})
                lista_canciones.append(cancion) #AGREGA CANCION A LA LISTA
                conjuntodecanciones -=1
            creador= db_usuarios[-1] #TU ERES EL CREADOR
            id_generado = generar_id() #GENERA TU ID
            descripcion= input("Ingresa la descripción >>> ") #TIENES QUE INGRESAR LOS DATOS
            datosnew=Playlist({id_generado}, {titulo_playlist}, {descripcion}, {creador}, lista_canciones)
            db_playlist.append(datosnew)      #SE AGREGA A LA LISTA DE PLAYLIS  
            print("Tu playlist fue creada exitosamente✅") #LA CREASTE CON EXITO
            break
        else: #VALIDACION NO ERES ESCUCHA
            print("El usuario no es de tipo escucha no puedes crear una playlist. Ingresa otro usuario o crea uno.")
            break

def buscador(db_albums,db_usuarios,db_playlist,db_canciones): #BUSQUEDA
    """4. El buscador deberá permitir buscar por:
    a. Nombre del músico
    b. Nombre del álbum
    c. Nombre de la canción
    d. Nombre del playlist"""
    while True:
        opcion=input("""Ingresa la opción por la que deseas buscar la canción:
                         1. Nombre del músico
                         2. Nombre del álbum
                         3. Nombre de la canción
                         4. Nombre del playlist 
                         5. Salir  >>>> """)
        if opcion == "1": #BUSCA USUARIOS MUSICO, NO ACEPTA USUARIOS ESCUCHA
            busqueda=input("Ingresa el nombre de músico ")
            x = True
            for user in db_usuarios:
                if user.name == busqueda:
                    if user.tipo == "musician":
                        print(user)
                        x = False
                    else:
                        break
            if x:
                print("El músico que intenta buscar no esta registrado ❌. Intente con otro músico ")
                break
        elif opcion == "2": #BUSCA ALBUMS POR SU NOMBRE
            album = buscaralbums(db_albums)
            album.play()
            if album == None:
                print("El álbum que intenta buscar no esta registrado ❌. Intente con otro álbum ")   
                break
            
            print(album)
        elif opcion == "3": #BUSCA CANCIONES POR SU NOMBRE
            cancion = buscarcancion(db_canciones)
            print(cancion)
            if cancion == None:
                print("La canción que intenta buscar no esta registrado ❌. Intente con otra canción ")
                break

            print(cancion)
        elif opcion == "4": #BUSCA PLAYLIST POR SU NOMBRE
            play = buscarplaylist(db_playlist)
            if play == None:
                print("La playlist que intenta buscar no esta registrado ❌. Intente con otro playlist ")    
                break

            print(play)
        elif opcion == "5":#SALE DEL PROGRAMA
            break
        else: #VALIDACION
            print("Opción no válida.")
            break
        
def buscarplaylist(db_playlist):#FUNCION PARA BUSCAR PLAYLIST
    busqueda=input("Ingresa el nombre del playlist ")
    for play in db_playlist:
        if play.name == busqueda:
            return play

def buscarcancion(db_canciones, busqueda = ""):#FUNCION PARA BUSCAR CANCIONES
    if busqueda == "":
        busqueda=input("Ingresa el nombre de la canción ")    
    for cancion in db_canciones:
        if cancion.name == busqueda:
            return cancion

def buscaralbums(db_albums, busqueda = ""):#FUNCION PARA BUSCAR ALBUMES
    if busqueda == "":
        busqueda=input("Ingresa el nombre del álbum:  ")
    for album in db_albums:
        if album.name == busqueda:
            return album
        
def buscarmusico(db_usuarios, busqueda = ""):#FUNCION PARA BUSCAR MUSICOS
    busqueda=input("Ingresa el nombre de músico ")
    for user in db_usuarios:
        if user.tipo == "musician":
                    if user.name == busqueda:
                        return user