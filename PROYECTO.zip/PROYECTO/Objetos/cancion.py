class Cancion:
    def __init__(self, id_album, id ,name ,duracion ,link, streams=0):
        self.id_album=id_album
        self.id=id
        self.name=name
        self.duracion= duracion
        self.link= link 
        self.streams=streams
        
    def __str__ (self):
        return f"""CANCIÓN: 
                   Id_album: {self.id_album}
                   Id: {self.id} 
                   Nombre: {self.name} 
                   Duracion: {self.duracion} 
                   Link: {self.link}
                   Streams: {self.streams}"""
    
    def play(self):
        self.streams += 1
        print(f"Escuchando canción: {self.name} ----> {self.streams} reproducciones")