class Playlist:
    def __init__(self, id, name, descripcion, creador, tracks: list, streams= 0):
        self.id=id
        self.name=name
        self.descripcion=descripcion
        self.creador=creador
        self.tracks=tracks
        self.streams= streams

    def __str__(self):
        return f"""PLAYLIST: 
                 Id: {self.id} 
                 Nombre: {self.name} 
                 Descripcion: {self.descripcion} 
                 Creador: {self.creador}
                 Tracks:{self.tracks}
                 Streams: {self.streams}"""
    
    def play(self):
        self.streams += 1
        print(f"Escuchando canción: {self.name} ----> {self.streams} reproducciones")
    

    