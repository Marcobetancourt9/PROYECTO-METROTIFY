class Like:
    def __init__(self, id, item, id_item):
        self.id=id
        self.item=item
        self.id_item=id_item

    def __str__(self):
        return f"""
           LIKES:
           Id de la persona: {self.id}
           Item: {self.item}
           Id del item: {self.id_item}"""