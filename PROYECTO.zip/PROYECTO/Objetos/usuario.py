class Usuario:
    def __init__(self, id, name, correo, tipo, username, streams=0):
        self.id=id
        self.name=name
        self.correo=correo
        self.tipo= tipo
        self.username= username
        self.streams=streams
        
    def __str__(self):
        return f"""USUARIO:
                 Id:{self.id} 
                 Nombre: {self.name} 
                 Correo: {self.correo} 
                 Tipo de usuario: {self.tipo}
                 Nombre de usuario: {self.username}
                 Streams: {self.streams}"""
    
    def play(self):
        self.streams += 1
        print(f"Viendo perfil: {self.name} ----> {self.streams} vistas")
    
class Musico(Usuario):
    def __init__(self, id, name, correo, tipo, username, albums, streams = 0):
        super().__init__(name, id, correo, tipo, username)
        self.albums=albums #lista de objetos albums[]
       
    def __str__(self):
        return f"""MUSICO:
                 Id:{self.id} 
                 Nombre: {self.name} 
                 Correo: {self.correo} 
                 Tipo de usuario: {self.tipo} 
                 Nombre de usuario:{self.username} 
                 Albums: {self.albums}
                 Streams: {self.streams}"""
    
    def play(self):
        self.streams += 1
        print(f"Viendo perfil: {self.name} ----> {self.streams} vistas")

class Escucha(Usuario):
    def __init__(self, id, name, correo, tipo, username, streams=0):
        super().__init__(name, id, correo, tipo, username, streams)
       
    def __str__(self):
        return f"""ESCUCHA: 
                 Id:{self.id}
                 Nombre: {self.name} 
                 Correo: {self.correo} 
                 Tipo de usuario: {self.tipo} 
                 Nombre de usuario: {self.username}
                 Streams: {self.streams}"""
    
    def play(self):
        self.streams += 1
        print(f"Viendo perfil: {self.name} ----> {self.streams} vistas")