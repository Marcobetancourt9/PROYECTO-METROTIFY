class Album:
    def __init__(self, id, name, genero, artista, cover, published, descripcion, streams = 0):
        self.id=id
        self.name=name
        self.genero=genero
        self.artista=artista
        self.cover=cover
        self.published=published
        self.descripcion=descripcion
        self.tracklist=[]
        self.streams = streams

    def __str__ (self):
        return f"""ALBUM: 
                 Id: {self.id}
                 Nombre: {self.name}
                 Genero: {self.genero}
                 Artista: {self.artista} 
                 Trancklist: {self.tracklist}       
                 Cover: {self.cover}         
                 Published: {self.published}
                 Descripcion: {self.descripcion}
                 Streams: {self.streams}"""
            
    def play(self):
        self.streams += 1
        print(f"Escuchando canción: {self.name} ----> {self.streams} reproducciones")   