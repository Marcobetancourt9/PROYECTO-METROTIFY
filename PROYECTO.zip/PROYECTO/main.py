from Modulos.manejodeinformacion import download_api, read_files, actualizacion
from Modulos.gestiondeperfil import crearperfil,buscarusuarios,cambiarinfo,borrar
from Modulos.gestiondemusica import crearalbum, escuchar, crearplaylist, buscador
from Modulos.gestiondeestadisticas import top_albums, top_artistas, top_canciones, top_escuchas
from Modulos.iniciodesesion import inicio

class App:#CLASE CON LAS LISTAS DE LAS BASE DE DATOS SE UTILIZARAN PARA EL PROGRAMA EN TOTAL
    def __init__(self):
        self.db_usuarios = []
        self.db_musicos = []
        self.db_oyentes = []
        self.db_albums = []
        self.db_canciones = []
        self.db_playlist = []
        self.db_likes = []

    def run(self):#CON ESTO EVITAMOS TENER VARIABLES GLOBALES EN SU TOTALIDAD
        self.db_usuarios, self.db_musicos, self.db_oyentes, self.db_albums, self.db_canciones, self.db_playlist = read_files()
        inicio(self.db_usuarios)

        while True:
            print('\n           Metrotify 🎵🎶🎙️🎤🎼')
            option = input('''
            Ingrese el numero correspondiente a la accion que desea realizar:
            1. Descargar informacion de la API (Esta opcion eliminara los datos guardados)
            2. Acceder al modulo de gestión perfil
            3. Acceder al modulo de gestión musical
            4. Acceder al modulo de gestión de interacciones
            5. Acceder al modulo de estadisticas
            6. Cerrar sistema
            >>> ''')
            if option == '1': #DESCARGAR API
                download_api()
            elif option == '2': #MODULO DE GESTION PERFIL
                self.gestion_perfil()
            elif option == '3': #MODULO DE GESTION MUSICAL
                self.gestion_musical()
            elif option == '4': #MODULO DE GESTION DE INTERACCIONES
                self.gestion_interacciones()
            elif option == '5': #MODULO DE GESTION DE ESTADISTICAS
                self.gestion_estadisticas()
            elif option == '6': #SALIR DEL SISTEMA
                print('\n           Ha salido del sistema con exito, hasta luego!')
                actualizacion()
                break
            else: # VALIDACION
                print('\n           Ingreso invalido!!!')

    def gestion_perfil(self): #ACCEDE A LA GESTION DE PERFILES
        while True:
            print('\n            GESTIÓN DE PERFILES🎵👨🧑👧👦👴')
            option = input('''
            Ingrese el numero correspondiente a la accion que desea realizar:
            1. Registrar nuevos usuarios.
            2. Buscar perfiles.
            3. Cambiar la información personal de la cuenta.
            4. Borrar los datos de la cuenta.
            5. Volver al menu principal.
            >>> ''')
            if option == '1': #REGISTRAR USUARIO
                print('\n           REGISTRO DE NUEVOS USUARIOS 👤 ')
                crearperfil(self.db_usuarios)
                print(self.db_usuarios[-1]) #SE REGISTRA UN USUARIO Y SE AÑADE DE ULTIMO
                break
            elif option == '2': #BUSCAR PERFILES
                user = buscarusuarios(self.db_usuarios) #BUSCA UN USUARIO EN LA LISTA DB USUARIOS SI NO LO ENCUENTRA ENVIA NONE
                if user == None:
                    print("El usuario que intenta buscar no esta registrado ❌. Intente con otro usuario ")
                    continue
                print(user)
                break
            elif option == '3': #CAMBIAR INFORMACIÓN
                cambiarinfo(self.db_usuarios) #CAMBIA LA INFORMACION DE UN USUARIO ESCOGIENDO QUE USUARIO Y QUE INFORMACIÓN
                break
            elif option == '4': #BORRAR DATOS
                borrar(self.db_usuarios) #REMUEVE A UN USUARIO DE LA LISTA
                break
            elif option == '5': #VOLVER AL MENU
                print('\n           Ha salido del modulo de gestión de perfiles con exito, hasta luego!')
                break
            else: # VALIDACION
                print('\n           Ingreso invalido!!!')

    def gestion_musical(self): #ACCEDE A LA GESTION DE MUSICA
        while True:
            print('\n            GESTIÓN DE MÚSICA🎵🎶🎙️🎤🎼')
            option = input('''
            Ingrese el numero correspondiente a la accion que desea realizar:
            1. Crear un álbum musical.
            2. Escuchar música del usuario músico.
            3. Crear una playlist.
            4. Buscar canción por músico, álbum, canción o playlist.
            5. Volver al menu principal.
            >>> ''')
            if option == '1': #CREAR ALBUM DE MUSICA
                crearalbum(self.db_albums, self.db_usuarios) #CREA UN ALBÚM CON LA CANTIDAD DE CANCIONES QUE SE QUIERAN, SOLO USUARIOS MUSICO
                break
            elif option == '2': #ESCUCHAR MUSICA
                escuchar(self.db_albums, self.db_canciones, self.db_usuarios, self.db_playlist)# SIMULA LA REPRODUCCION DE MUSICA ESCOGIENDO UNA DE DOS OPCIONES
                break
            elif option == '3': #CREAR PLAYLIST
                crearplaylist(self.db_albums, self.db_usuarios) #CREA UNA PLAYLIST CON LA CANTIDAD DE CANCIONES QUE SE QUIERAN, SOLO USUARIOS ESCUCHA
                break
            elif option == '4': #BUSCAR CANCIÓN
                buscador(self.db_albums, self.db_usuarios, self.db_playlist, self.db_canciones) #BUSCA UNA CANCION ESCOGIENDO UNA DE TRES OPCIONES
                break
            elif option == '5': #VOLVER AL MENU
                print('\n           Ha salido del modulo de gestión de musical con exito, hasta luego!')
                break
            else: # VALIDACION
                print('\n           Ingreso invalido!!!')

    def gestion_interacciones(self): #ACCEDE A LA GESTION DE INTERACCIONES
        while True:
            option = input("""
            Ingrese el numero correspondiente a la accion que desea realizar:
            1. Dar like al perfil de un músico
            2. Dar like al perfil de un álbum
            3. Dar like a una canción del tracklist
            4. Dar like a una playlist
            5. Remover su like de cualquiera de los anteriores.
            6. Volver al menu
            >>>>>> """)

            if option == '1': #LIKE AL PERFIL DE UN MUSICO
                pass
            elif option == '2':#LIKE AL PERFIL DE UN ALBUM
                pass
            elif option == '3': #LIKE A UNA CANCION DEL TRACKLIST
                pass
            elif option == '4': #LIKE A UNA PLAYLIST
                pass
            elif option == '5': #REMOVER LIKE
                pass
            elif option == '6': #VOLVER AL MENU
                print('\n           Ha salido del modulo de gestión de interacciones con exito, hasta luego!')
                break
            else: # VALIDACION
                print('\n           Ingreso invalido!!!')

    def gestion_estadisticas(self): #ACCEDE A LA GESTION DE ESTADISTICAS
        while True:
            print('\n           📊 MODULO DE ESTADISTICAS 📊')
            option = input('''
            Ingrese el numero correspondiente a la accion que desea realizar:
            1. Top 5 de músicos con mayor cantidad de streams
            2. Top 5 de álbumes con mayor cantidad de streams
            3. Top 5 de canciones con mayor cantidad de streams
            4. Top 5 de escuchas con mayor cantidad de streams
            5. Volver al menu principal
            >>>>>>  ''')
            if option == '1':
                top_artistas(self.db_usuarios, "artistas") #ESTADISTICAS DE LOS MUSICOS CON MAYOR CANTIDAD DE STREAMS; SEGUNDO PARAMETRO PARA LA GRAFICA
            elif option == '2':
                top_albums(self.db_albums, "albumes") #ESTADISTICAS DE LOS CON ALBUMES MAYOR CANTIDAD DE STREAMS; SEGUNDO PARAMETRO PARA LA GRAFICA
            elif option == '3':
                top_canciones(self.db_canciones, "canciones") #ESTADISTICAS DE LAS CANCIONES CON MAYOR CANTIDAD DE STREAMS; SEGUNDO PARAMETRO PARA LA GRAFICA
            elif option == '4':
                top_escuchas(self.db_usuarios, "escuchas") #ESTADISTICAS DE LOS ESCUCHAS CON MAYOR CANTIDAD DE STREAMS; SEGUNDO PARAMETRO PARA LA GRAFICA
            elif option == '5':
                break
            else:
                print('\n           Ingreso invalido!!!')

# INICIAMOS LA CLASE APP Y CORREMOS EL RUN PARA QUE FUNCIONE EL PROGRAMA
app = App()
app.run()